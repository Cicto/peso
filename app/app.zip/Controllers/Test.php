<?php

namespace App\Controllers;
use App\Models\MasterModel;
use Myth\Auth\Entities\User;
use App\Libraries\TemplateLib;
use Hermawan\DataTables\DataTable;

class Test extends BaseController
{
    public function index()
    {
        return "asd";
    }
}